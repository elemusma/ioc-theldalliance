# python-web-scraping

# Try this link:
# https://stackoverflow.com/questions/60809986/access-denied-while-scraping-seekingalpha-transcript-with-beautifulsoup

# Advanced GitHub Project:
# https://github.com/jamesjynus/Web_Scraping_Project